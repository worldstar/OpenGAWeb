package OpenGA_Run;

import openga.operator.crossover.twoPointCrossover2;
import openga.operator.crossover.CrossoverI;
import openga.chromosomes.population;
import openga.chromosomes.populationI;
import openga.util.timeClock;

import openga.applications.TSP;
import openga.applications.data.TSPInstances;
import openga.ObjectiveFunctions.util.generateMatrix_EuclideanDist;

public class TSP_Run {
    
    public static void main(String[] args) {
        System.out.print("TSP SGA 1010 DOE");
        TSP TSP1 = new TSP();
        double crossoverRate[], mutationRate[];
        crossoverRate = new double[]{1.0};//1, 0.5
        mutationRate  = new double[]{0.5};
        int counter = 0;
        double elitismArray[] = new double[]{0.2};
        int generationsArray[] = new int[]{1000};
        int numInstances = 1;
        int repeat = 30;

        //to test different kinds of combinations.
          for(int i = 1 ; i < 2 ; i ++ ){//numInstances
            //initiate scheduling data, we get the data from a program.
            openga.applications.data.TSPInstances TSPInstances1 = new openga.applications.data.TSPInstances();
            TSPInstances1.setData(TSPInstances1.getFileName(i));
            TSPInstances1.getDataFromFile();
            String instanceName = TSPInstances1.getFileName(i);
            TSPInstances1.calcEuclideanDistanceMatrix();
            int length = TSPInstances1.getSize();
            
            for(int j = 0 ; j < crossoverRate.length ; j ++ ){
              for(int k = 0 ; k < mutationRate.length ; k ++ ){
                for(int n = 0 ; n < elitismArray.length ; n ++ ){
                    for(int m = 0 ; m < repeat ; m ++ ){
                      System.out.println(counter);
                      TSP1.setParameter(i, crossoverRate[j], mutationRate[k], counter, elitismArray[n], generationsArray[0],
                              TSPInstances1.getOriginalPoint(), TSPInstances1.getCoordinates(),
                              TSPInstances1.getDistanceMatrix(), TSPInstances1.getSize(), instanceName);
                      TSP1.initiateVars();
                      TSP1.start();
                      counter ++;
                    }             
                }
              }
            }
          }//end for   
        System.exit(0);
      }

}